document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("cadastroEnderecoForm");

    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        // Captura dos valores do formulário
        const cep = document.getElementById("cep").value;
        const rua = document.getElementById("rua").value;
        const numero = document.getElementById("numero").value;
        const cidade = document.getElementById("cidade").value;
        const estado = document.getElementById("estado").value;
        const comprimento = document.getElementById("comprimento").value;
        const bairro = document.getElementById("bairro").value;

        try {
            // Requisição POST para a API de endereço
            const response = await fetch("http://localhost:8080/enderecos", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    cep,
                    rua,
                    numero,
                    cidade,
                    estado,
                    comprimento,
                    bairro
                }),
            });

            if (response.ok) {
                alert("Endereço cadastrado com sucesso!");
                // Redireciona para outra página após 1 segundo
                setTimeout(() => {
                    window.location.href = "confirmacao.html"; // Altere para a página desejada
                }, 1000);
            } else {
                alert("Erro ao cadastrar o endereço");
            }
        } catch (error) {
            console.error("Erro ao cadastrar o endereço:", error);
        }
    });
});