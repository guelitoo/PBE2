package com.senai.cadastroendereco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroenderecoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroenderecoApplication.class, args);
	}

}
